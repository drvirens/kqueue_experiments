#ifndef SNMPTLSTMCERTTOTSNTABLE_H
#define SNMPTLSTMCERTTOTSNTABLE_H

config_require(tlstm-mib/snmpTlstmCertToTSNTable/snmpTlstmCertToTSNTable)

#endif                          /* SNMPTLSTMCERTTOTSNTABLE_H */
